#include <stdio.h>   // Necesario para poder usar printf

int main(void)       // Punto de inicio del programa
{
    printf("- Hola mundo! Soy un programa en C. \n - IES Rafael Alberti. ");  
    // Muestra en pantalla el texto indicado
    // "\n" hace que el texto continúe en la siguiente línea

    return 0;        // Indica que el programa terminó correctamente
}