print ("- Hola mundo!. Soy un programa en Python.") # Muestra el mensaje por pantalla
print("- IES Rafael Alberti.") # Muestra el mensaje por pantalla