#include <stdio.h>   // Necesario para poder usar printf

int main (void) {    // Punto de inicio del programa

    for (int i = 0; i < 21; i++) {   // Bucle que repite 21 veces
        printf("Jose Manuel Ramirez Alegre\n");   // Muestra tu nombre y baja a la siguiente línea
    }

}  