for i in range(1,21): # Bucle para iterar 20 veces
    print ("Jose Ramírez") # Muestra 20 veces el mensaje por pantalla