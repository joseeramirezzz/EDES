#include <stdio.h>

int main(void) {
    int edad = 18;              
    float nota = 7.50f;         
    double pi = 3.1415926535;   
    char inicial = 'A';         

    printf("Edad (int): %d\n", edad);
    printf("Nota (float): %.2f\n", nota);
    printf("PI (double): %.6f\n", pi);
    printf("Inicial (char): %c\n", inicial);

    return 0;
}
